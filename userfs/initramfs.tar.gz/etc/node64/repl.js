'use strict';

const repl = require('node:repl');

repl.start({
    prompt: '> ',
    terminal: true,
    useGlobal: true
});
